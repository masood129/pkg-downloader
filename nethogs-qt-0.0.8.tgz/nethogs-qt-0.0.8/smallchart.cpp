/*
 * smallchart.cpp
 *
 * Copyright (c) 2020 Stephane List
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 */


#include "smallchart.h"

#include <QtCharts/QSplineSeries>
#include <QtCharts/QValueAxis>
#include <QtCharts/QLogValueAxis>
#include <QtCharts/QDateTimeAxis>

#include <QtCore/QtMath>

#include <QtDebug>

QT_CHARTS_USE_NAMESPACE

SmallChart::SmallChart(QWidget * /*parent*/)
{
    QChart * chart = new QChart();
    setChart(chart);
    setRubberBand(QChartView::HorizontalRubberBand);
    x = 1;
    max_val = 1;

    series_recv.setName(tr("RECV"));
    series_sent.setName(tr("SENT"));

    chart->addSeries(&series_recv);
    chart->addSeries(&series_sent);

    QValueAxis *axisX = new QValueAxis;
    axisX->setTitleText(tr("Seconds"));
    axisX->setTickCount(series_recv.count());
    chart->addAxis(axisX, Qt::AlignBottom);
    series_recv.attachAxis(axisX);
    series_sent.attachAxis(axisX);

    QLogValueAxis *axisY = new QLogValueAxis;
    axisY->setLabelFormat("%g");
    axisY->setTitleText("Bytes/s (Logarithmic Axis)");
    axisY->setBase(8.0);
//    axisY->setMinorTickCount(-1);
    chart->addAxis(axisY, Qt::AlignLeft);
    series_recv.attachAxis(axisY);
    series_sent.attachAxis(axisY);

    setRenderHint(QPainter::Antialiasing);
}

void SmallChart::add_points(quint64 r,quint64 s)
{
    series_recv.append(x,r+1);
    series_sent.append(x,s+1);

    max_val = qMax(max_val, r+1);
    max_val = qMax(max_val, s+1);

    chart()->axes(Qt::Horizontal).first()->setRange(0, x);
    chart()->axes(Qt::Vertical).first()->setRange(1, max_val);

    x++;
}


void SmallChart::reset()
{
    series_recv.clear();
    series_sent.clear();
    x=1;
    max_val = 1;
    chart()->axes(Qt::Horizontal).first()->setRange(0,1);
    chart()->axes(Qt::Vertical).first()->setRange(1,2);
}

void SmallChart::setTitle(const QString &title)
{
    chart()->setTitle(title);
}
