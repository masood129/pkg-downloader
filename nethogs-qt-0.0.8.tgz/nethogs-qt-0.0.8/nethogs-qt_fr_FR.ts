<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="20"/>
        <source>nethogs-qt</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="49"/>
        <source>PID</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="54"/>
        <source>User</source>
        <translation>Utilisateur</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="59"/>
        <source>App</source>
        <translation>Application</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="64"/>
        <source>Status</source>
        <translation>Statut</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="69"/>
        <source>recv</source>
        <translation>reçu</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="74"/>
        <source>sent</source>
        <translation>envoyé</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="79"/>
        <source>recv/s</source>
        <translation>reçu/s</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="84"/>
        <source>sent/s</source>
        <translation>envoyé/s</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="89"/>
        <source>devname</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="94"/>
        <source>More</source>
        <translation>Plus</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="131"/>
        <source>Source IP</source>
        <translation>IP source</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="136"/>
        <source>Source Port</source>
        <translation>Port source</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="141"/>
        <source>Dest IP</source>
        <translation>IP Destination</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="146"/>
        <source>Dest Port</source>
        <translation>Port Destination</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="151"/>
        <source>lookup</source>
        <translation>résoudre</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="171"/>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="177"/>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="184"/>
        <source>View</source>
        <translation>&amp;Vue</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="207"/>
        <source>&amp;About</source>
        <translation>&amp;A propos</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="212"/>
        <source>&amp;Exit</source>
        <translation>&amp;Quitter</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="217"/>
        <source>About &amp;Qt</source>
        <translation>Apropos de Qt</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="226"/>
        <source>Pause</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="235"/>
        <source>Reset</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="240"/>
        <source>Toggle global chart view</source>
        <translation>Basculer la vue du graphique global</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="245"/>
        <source>Process chart view</source>
        <translation>Graphe d&apos;un process</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="254"/>
        <source>Save</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="257"/>
        <source>Save network table in CSV</source>
        <translation>Enregistrer la table des connexions réseau dans un fichier CSV</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="98"/>
        <location filename="mainwindow.cpp" line="503"/>
        <source>Global Chart</source>
        <translation>Vue globale</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="389"/>
        <source>About nethogs-qt</source>
        <translation>A propos de nethogs-qt</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="389"/>
        <source>nethogs-qt version %1
is a free software under GPL v3 !</source>
        <translation>nethogs-qt version %1
est un logiciel libre sous licence GPL v3 !</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="473"/>
        <source>Running!</source>
        <translation>En fonctionement !</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="476"/>
        <source>Paused!</source>
        <translation>En pause !</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="513"/>
        <source>Save network table</source>
        <translation>Enregistrer la table des connexions réseau</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="513"/>
        <source>CSV file (*.csv);;All Files (*)</source>
        <translation>Fichier CSV (*.csv);;Tous les fichiers (*)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="520"/>
        <source>Unable to open file</source>
        <translation>Impossible d&apos;ouvrir le fichier</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="529"/>
        <source>source IP</source>
        <translation>IP source</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="530"/>
        <source>source port</source>
        <translation>Port source</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="531"/>
        <source>dest IP</source>
        <translation>IP Destination</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="532"/>
        <source>dest port</source>
        <translation>Port Destination</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="533"/>
        <source>FQDN</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SmallChart</name>
    <message>
        <location filename="smallchart.cpp" line="44"/>
        <source>RECV</source>
        <translation>reçu</translation>
    </message>
    <message>
        <location filename="smallchart.cpp" line="45"/>
        <source>SENT</source>
        <translation>envoyé</translation>
    </message>
    <message>
        <location filename="smallchart.cpp" line="51"/>
        <source>Seconds</source>
        <translation>Secondes</translation>
    </message>
</context>
<context>
    <name>process_chart_dialog</name>
    <message>
        <location filename="process_chart_dialog.ui" line="14"/>
        <source>Process chart</source>
        <translation>Graphe d&apos;un process</translation>
    </message>
    <message>
        <location filename="process_chart_dialog.ui" line="22"/>
        <source>Process name:</source>
        <translation>Nom du process:</translation>
    </message>
    <message>
        <location filename="process_chart_dialog.ui" line="32"/>
        <source>Enable chart</source>
        <translation>Activer le graphique</translation>
    </message>
</context>
</TS>
